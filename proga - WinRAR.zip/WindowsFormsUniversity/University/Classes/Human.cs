﻿using System;
using System.IO;
using Newtonsoft.Json;

//створюємо простір імен University
namespace University
{
    public class Human //публічний клас Human
    {
        //створення приватних змінних класу
        protected string _name;
        protected string _surname;
        protected int _age;
        protected Adress _adress;

        //конструктори
        //конструктор за замовчуванням
        public Human()
        {
            this._name = "Name";
            this._surname = "Surname";
            this._age = 18;
            this._adress = new Adress();
        }

        //констуктор з параметром
        public Human(string name, string surname, int age, Adress adress)
        {
            this._name = name;
            this._surname = surname;
            this._age = age;
            this._adress = adress;
        }

        //методи доступу до змінних класу
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Surname
        {
            get { return _surname; }
            set { _surname = value; }
        }

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        //методи класу
        //метод зміни даних
        public void changeInfo()
        {
            Console.WriteLine("Введите новое имя: ");
            this._name = Console.ReadLine();
            Console.WriteLine("Введите новую фамилию: ");
            this._surname = Console.ReadLine();
            Console.WriteLine("Введите новий возраст: ");
            this._age = Int32.Parse(Console.ReadLine());
        }
        //метод запису даних до json-файлу
        public void WriteToJson(string fileLink) 
        {
            Human human = this;
            string JsonData = JsonConvert.SerializeObject(human);
            File.WriteAllText(fileLink, JsonData);

        }

        //перегрузка оператора більше 
        public static bool operator >(Human one, Human two) 
        {
            bool result = one._age > two._age;
            return result;
        }

        //перегрузка оператора меньше
        public static bool operator <(Human one, Human two)
        {
            bool result = one._age < two._age;
            return result;
        }

        //друкування данних
        public virtual void printInfo() 
        {
            Console.WriteLine(dataToStr());
        }

        //метод переводу всіх данних в строчні змінні для виводу на екран
        public string dataToStr()
        {
            string str;
            str = "Name: " + this._name + "\n" +
                "Surname: " + this._surname + "\n" +
                "Age: " + this._age.ToString() + "\n" + _adress.adressToString();
            return str;
        }
        
    }
}

