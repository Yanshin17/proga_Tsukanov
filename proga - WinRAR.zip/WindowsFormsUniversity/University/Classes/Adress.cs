﻿using System;


//створюємо простір імен University
namespace University
{
    public class Adress //публічний клас Adress
    {
        //створення приватних змінних класу
        private string _country;
        private string _city;
        private string _street;
        private int _house;

        //конструктори
        //конструктор за замовчуванням
        public Adress()
        {
            this._country = "Україна";
            this._city = "Херсон";
            this._street = "Університетська";
            this._house = 11;
        }

        //констуктор з параметром
        public Adress(string country, string city, string street, int house)
        {
            this._country = country;
            this._city = city;
            this._street = street;
            this._house = house;
        }

        //методи доступу до змінних класу
        public string Country
        {
            get { return _country; }
            set { _country = value; }
        }

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }

        public string Street
        {
            get { return _street; }
            set { _street = value; }
        }

        public int House
        {
            get { return _house; }
            set { _house = value; }
        }

        //методи класу
        //метод переведення даних до текстового формату
        public string adressToString()
        {
            return
                "Country: " + this._country + "\n" +
                "City: " + this._city + "\n" +
                "Street: " + this._street + "\n" +
                "House: " + this._house.ToString();
        }

        //метод вводу данних з клавіатури
        public Adress inputAdress()
        {
            Console.WriteLine("Country: ");
            string country = Console.ReadLine();
            Console.WriteLine("City: ");
            string city = Console.ReadLine();
            Console.WriteLine("Street: ");
            string street = Console.ReadLine();
            Console.WriteLine("House: ");
            int house = int.Parse(Console.ReadLine());
            Adress adress = new Adress(country, city, street, house);
            return adress;
        }
    }
}


