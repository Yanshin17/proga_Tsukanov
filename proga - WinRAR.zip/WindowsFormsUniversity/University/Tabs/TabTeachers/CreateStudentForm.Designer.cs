﻿namespace University
{
    partial class CreateStudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SavePerson = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this._house = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this._street = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this._city = new System.Windows.Forms.TextBox();
            this.labelC = new System.Windows.Forms.Label();
            this._country = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this._age = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this._surname = new System.Windows.Forms.TextBox();
            this.LName = new System.Windows.Forms.Label();
            this._name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this._admissionYear = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SavePerson
            // 
            this.SavePerson.Location = new System.Drawing.Point(87, 429);
            this.SavePerson.Margin = new System.Windows.Forms.Padding(4);
            this.SavePerson.Name = "SavePerson";
            this.SavePerson.Size = new System.Drawing.Size(229, 33);
            this.SavePerson.TabIndex = 34;
            this.SavePerson.Text = "Зберегти";
            this.SavePerson.UseVisualStyleBackColor = true;
            this.SavePerson.Click += new System.EventHandler(this.SavePerson_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(153, 231);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 25);
            this.label4.TabIndex = 33;
            this.label4.Text = "Адреса";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(73, 366);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 18);
            this.label10.TabIndex = 32;
            this.label10.Text = "Будинок";
            // 
            // _house
            // 
            this._house.Location = new System.Drawing.Point(186, 360);
            this._house.Margin = new System.Windows.Forms.Padding(4);
            this._house.Name = "_house";
            this._house.Size = new System.Drawing.Size(153, 22);
            this._house.TabIndex = 31;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(73, 333);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 18);
            this.label9.TabIndex = 30;
            this.label9.Text = "Вулиця";
            // 
            // _street
            // 
            this._street.Location = new System.Drawing.Point(186, 330);
            this._street.Margin = new System.Windows.Forms.Padding(4);
            this._street.Name = "_street";
            this._street.Size = new System.Drawing.Size(153, 22);
            this._street.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(73, 306);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 18);
            this.label8.TabIndex = 28;
            this.label8.Text = "Місто";
            // 
            // _city
            // 
            this._city.Location = new System.Drawing.Point(186, 300);
            this._city.Margin = new System.Windows.Forms.Padding(4);
            this._city.Name = "_city";
            this._city.Size = new System.Drawing.Size(153, 22);
            this._city.TabIndex = 27;
            // 
            // labelC
            // 
            this.labelC.AutoSize = true;
            this.labelC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelC.Location = new System.Drawing.Point(73, 273);
            this.labelC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(53, 18);
            this.labelC.TabIndex = 26;
            this.labelC.Text = "Країна";
            // 
            // _country
            // 
            this._country.Location = new System.Drawing.Point(186, 270);
            this._country.Margin = new System.Windows.Forms.Padding(4);
            this._country.Name = "_country";
            this._country.Size = new System.Drawing.Size(153, 22);
            this._country.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(61, 142);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "Вік";
            // 
            // _age
            // 
            this._age.Location = new System.Drawing.Point(174, 141);
            this._age.Margin = new System.Windows.Forms.Padding(4);
            this._age.Name = "_age";
            this._age.Size = new System.Drawing.Size(153, 22);
            this._age.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(61, 110);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "Прізвище";
            // 
            // _surname
            // 
            this._surname.Location = new System.Drawing.Point(174, 109);
            this._surname.Margin = new System.Windows.Forms.Padding(4);
            this._surname.Name = "_surname";
            this._surname.Size = new System.Drawing.Size(153, 22);
            this._surname.TabIndex = 19;
            // 
            // LName
            // 
            this.LName.AutoSize = true;
            this.LName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LName.Location = new System.Drawing.Point(59, 80);
            this.LName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(33, 18);
            this.LName.TabIndex = 18;
            this.LName.Text = "Ім\'я";
            // 
            // _name
            // 
            this._name.Location = new System.Drawing.Point(174, 79);
            this._name.Margin = new System.Windows.Forms.Padding(4);
            this._name.Name = "_name";
            this._name.Size = new System.Drawing.Size(153, 22);
            this._name.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(61, 178);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 18);
            this.label5.TabIndex = 37;
            this.label5.Text = "Рік навчання";
            // 
            // _admissionYear
            // 
            this._admissionYear.Location = new System.Drawing.Point(174, 177);
            this._admissionYear.Margin = new System.Windows.Forms.Padding(4);
            this._admissionYear.Name = "_admissionYear";
            this._admissionYear.Size = new System.Drawing.Size(153, 22);
            this._admissionYear.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(57, 22);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(292, 25);
            this.label3.TabIndex = 38;
            this.label3.Text = "Введіть данні про студента";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // CreateStudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 507);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this._admissionYear);
            this.Controls.Add(this.SavePerson);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this._house);
            this.Controls.Add(this.label9);
            this.Controls.Add(this._street);
            this.Controls.Add(this.label8);
            this.Controls.Add(this._city);
            this.Controls.Add(this.labelC);
            this.Controls.Add(this._country);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._age);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._surname);
            this.Controls.Add(this.LName);
            this.Controls.Add(this._name);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CreateStudentForm";
            this.Text = "Данні про студента";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SavePerson;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox _house;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox _street;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox _city;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.TextBox _country;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox _age;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox _surname;
        private System.Windows.Forms.Label LName;
        private System.Windows.Forms.TextBox _name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox _admissionYear;
        private System.Windows.Forms.Label label3;
    }
}