﻿namespace University
{
    partial class CreateTeacherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SavePerson = new System.Windows.Forms.Button();
            this.LName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelC = new System.Windows.Forms.Label();
            this._house = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this._street = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this._city = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this._country = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this._age = new System.Windows.Forms.TextBox();
            this._salary = new System.Windows.Forms.TextBox();
            this._surname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SavePerson
            // 
            this.SavePerson.BackColor = System.Drawing.Color.White;
            this.SavePerson.FlatAppearance.BorderSize = 0;
            this.SavePerson.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SavePerson.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SavePerson.ForeColor = System.Drawing.Color.Black;
            this.SavePerson.Location = new System.Drawing.Point(84, 507);
            this.SavePerson.Margin = new System.Windows.Forms.Padding(4);
            this.SavePerson.Name = "SavePerson";
            this.SavePerson.Size = new System.Drawing.Size(312, 50);
            this.SavePerson.TabIndex = 15;
            this.SavePerson.Text = "Save";
            this.SavePerson.UseVisualStyleBackColor = false;
            this.SavePerson.Click += new System.EventHandler(this.SavePerson_Click);
            // 
            // LName
            // 
            this.LName.AutoSize = true;
            this.LName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LName.ForeColor = System.Drawing.Color.Black;
            this.LName.Location = new System.Drawing.Point(31, 33);
            this.LName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(374, 29);
            this.LName.TabIndex = 1;
            this.LName.Text = "Введіть данні про викладача";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(31, 166);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Вік";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(31, 127);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Прізвище";
            // 
            // labelC
            // 
            this.labelC.AutoSize = true;
            this.labelC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelC.ForeColor = System.Drawing.Color.Black;
            this.labelC.Location = new System.Drawing.Point(31, 320);
            this.labelC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(90, 29);
            this.labelC.TabIndex = 7;
            this.labelC.Text = "Країна";
            // 
            // _house
            // 
            this._house.Location = new System.Drawing.Point(252, 460);
            this._house.Margin = new System.Windows.Forms.Padding(4);
            this._house.Name = "_house";
            this._house.Size = new System.Drawing.Size(153, 22);
            this._house.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(31, 359);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 29);
            this.label8.TabIndex = 9;
            this.label8.Text = "Місто";
            // 
            // _street
            // 
            this._street.Location = new System.Drawing.Point(252, 413);
            this._street.Margin = new System.Windows.Forms.Padding(4);
            this._street.Name = "_street";
            this._street.Size = new System.Drawing.Size(153, 22);
            this._street.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(31, 406);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 29);
            this.label9.TabIndex = 11;
            this.label9.Text = "Вулиця";
            // 
            // _city
            // 
            this._city.Location = new System.Drawing.Point(252, 366);
            this._city.Margin = new System.Windows.Forms.Padding(4);
            this._city.Name = "_city";
            this._city.Size = new System.Drawing.Size(153, 22);
            this._city.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(31, 453);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 29);
            this.label10.TabIndex = 13;
            this.label10.Text = "Будинок";
            // 
            // _country
            // 
            this._country.Location = new System.Drawing.Point(252, 320);
            this._country.Margin = new System.Windows.Forms.Padding(4);
            this._country.Name = "_country";
            this._country.Size = new System.Drawing.Size(153, 22);
            this._country.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(31, 272);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "Адреса";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // _age
            // 
            this._age.Location = new System.Drawing.Point(252, 173);
            this._age.Margin = new System.Windows.Forms.Padding(4);
            this._age.Name = "_age";
            this._age.Size = new System.Drawing.Size(153, 22);
            this._age.TabIndex = 4;
            this._age.TextChanged += new System.EventHandler(this._age_TextChanged);
            // 
            // _salary
            // 
            this._salary.Location = new System.Drawing.Point(252, 227);
            this._salary.Margin = new System.Windows.Forms.Padding(4);
            this._salary.Name = "_salary";
            this._salary.Size = new System.Drawing.Size(153, 22);
            this._salary.TabIndex = 26;
            this._salary.TextChanged += new System.EventHandler(this._salary_TextChanged);
            // 
            // _surname
            // 
            this._surname.Location = new System.Drawing.Point(252, 134);
            this._surname.Margin = new System.Windows.Forms.Padding(4);
            this._surname.Name = "_surname";
            this._surname.Size = new System.Drawing.Size(153, 22);
            this._surname.TabIndex = 2;
            this._surname.TextChanged += new System.EventHandler(this._surname_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(31, 220);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 29);
            this.label3.TabIndex = 27;
            this.label3.Text = "Заробітна плата";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(252, 94);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(153, 22);
            this.textBox1.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(31, 88);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 29);
            this.label5.TabIndex = 29;
            this.label5.Text = "Ім\'я";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // CreateTeacherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(482, 582);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this._surname);
            this.Controls.Add(this._salary);
            this.Controls.Add(this.SavePerson);
            this.Controls.Add(this._age);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._country);
            this.Controls.Add(this.labelC);
            this.Controls.Add(this.label10);
            this.Controls.Add(this._house);
            this.Controls.Add(this._city);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this._street);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CreateTeacherForm";
            this.Text = "Данні про викладача";
            this.Load += new System.EventHandler(this.CreateTeacherForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SavePerson;
        private System.Windows.Forms.Label LName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.TextBox _house;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox _street;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox _city;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox _country;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox _age;
        private System.Windows.Forms.TextBox _salary;
        private System.Windows.Forms.TextBox _surname;
        private System.Windows.Forms.TextBox label19;
        private System.Windows.Forms.Label _name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
    }
}